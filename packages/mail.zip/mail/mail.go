package mail

import (
	"crypto/tls"
	"fmt"
	"log"
	"net/smtp"
	"strings"

	. "../virtualmachine"
)

type Mail struct {
	Sender  string
	To      []string
	Cc      []string
	Bcc     []string
	Subject string
	Body    string
}

type SmtpServer struct {
	Host      string
	Port      string
	TlsConfig *tls.Config
}

func (s *SmtpServer) ServerName() string {
	return s.Host + ":" + s.Port
}

func (mail *Mail) BuildMessage() string {
	header := ""
	header += fmt.Sprintf("From: %s\r\n", mail.Sender)
	if len(mail.To) > 0 {
		header += fmt.Sprintf("To: %s\r\n", strings.Join(mail.To, ";"))
	}
	if len(mail.Cc) > 0 {
		header += fmt.Sprintf("Cc: %s\r\n", strings.Join(mail.Cc, ";"))
	}

	header += fmt.Sprintf("Subject: %s\r\n", mail.Subject)
	header += "\r\n" + mail.Body

	return header
}

func Send_Mail(vm *VirtualMachine) {
	mail := Mail{}
	// func Send_Mail (Sender To Body Password)
	mail.Sender = vm.Pop().(string)
	mail.To = []string{vm.Pop().(string)}
	mail.Body = vm.Pop().(string)

	messageBody := mail.BuildMessage()

	smtpServer := SmtpServer{Host: "smtp.gmail.com", Port: "465"}
	smtpServer.TlsConfig = &tls.Config{
		InsecureSkipVerify: true,
		ServerName:         smtpServer.Host,
	}

	auth := smtp.PlainAuth("", mail.Sender, vm.Pop().(string), smtpServer.Host)

	conn, err := tls.Dial("tcp", smtpServer.ServerName(), smtpServer.TlsConfig)
	if err != nil {
		log.Panic(err)
	}

	client, err := smtp.NewClient(conn, smtpServer.Host)
	if err != nil {
		log.Panic(err)
	}

	// step 1: Use Auth
	if err = client.Auth(auth); err != nil {
		log.Panic(err)
	}

	// step 2: add all from and to
	if err = client.Mail(mail.Sender); err != nil {
		log.Panic(err)
	}
	receivers := append(mail.To, mail.Cc...)
	receivers = append(receivers, mail.Bcc...)
	for _, k := range receivers {
		log.Println("sending to: ", k)
		if err = client.Rcpt(k); err != nil {
			log.Panic(err)
		}
	}

	// Data
	w, err := client.Data()
	if err != nil {
		log.Panic(err)
	}

	_, err = w.Write([]byte(messageBody))
	if err != nil {
		log.Panic(err)
	}

	err = w.Close()
	if err != nil {
		log.Panic(err)
	}

	client.Quit()

	log.Println("Mail sent successfully")
}

func Help(vm *VirtualMachine) {
	fmt.Println(`
function mail.SendMail
{
	arg1: string sender
	arg2: string to
	arg3: string body
	arg3: string password (to the sending email)

	This function sends an email to "to" from the email "sender"
}`)
}

func InstallLibrary(vm *VirtualMachine) {
	vm.Library["mail.send"] = Send_Mail
	vm.Push("{ mail.send % }")
	vm.Push("mail.SendMail")
	vm.Op_store(false)
	vm.Library["mail.help_function"] = Help
	vm.Push("{ mail.help_function % }")
	vm.Push("mail.help")
	vm.Op_store(false)
}
